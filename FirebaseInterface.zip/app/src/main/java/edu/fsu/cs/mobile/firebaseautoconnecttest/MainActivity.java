package edu.fsu.cs.mobile.firebaseautoconnecttest;

import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity
        implements MainFragment.OnButtonClickecdListener,
        GameFragment.OnFragmentInteractionListener {

    Zone zone1;
    Zone zone2;
    Zone zone3;
    Zone zone4;
    Zone zone5;
    Zone zone6;

    @Override
    public void onButtonClicked(View v, String email, String password) {


        if (v.getId() == R.id.login_button) {

            if (!email.equals("") && !password.equals("")) {
                auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                            Log.i("MainActivity", task.getException().toString());
                            return;

                        }
                        Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.main_frame, GameFragment.newInstance(new MyUser(auth.getCurrentUser().getEmail(), "ID+PLACEHOLDER")))
                                .commit();

                    }
                });
                return;
            } else {
                Toast.makeText(this, "Empty Fields", Toast.LENGTH_SHORT).show();
                return;
            }
        } else if (v.getId() == R.id.register_button) {

            auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (!task.isSuccessful()) {
                        Toast.makeText(MainActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    }
                }
            });


        }
    }


    @Override
    public void onFragmentInteraction(View v, String id) {
        if (v.getId() == R.id.submit_button)
            pushToDatabase(auth.getCurrentUser(), id);
        else if (v.getId() == R.id.garnet_button) {
            incrementGarnetScore(id);
        } else if (v.getId() == R.id.gold_button) {
            incrementGoldScore(id);
        } else if (v.getId() == R.id.zone_button) {
            getZoneInfo(id);
        } else if (v.getId() == R.id.logout_button) {
            Log.i("MainActivity", "Signing Out...");
            auth.signOut();
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.main_frame, MainFragment.newInstance())
                    .commit();
        }
    }


    FirebaseAuth auth;
    GoogleApiClient mGoogleApiClient;
    Button loginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize default zones
        zone1 = new Zone();
        zone2 = new Zone();
        zone3 = new Zone();
        zone4 = new Zone();
        zone5 = new Zone();
        zone6 = new Zone();

        auth = FirebaseAuth.getInstance();


        //Load zone data from database
        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot zoneSnapshot : dataSnapshot.getChildren()) {
                    Zone currentZone = zoneSnapshot.getValue(Zone.class);
                    switch (zoneSnapshot.getKey()) {
                        case ("Zone1"): {

                            zone1.setgarnetscore(currentZone.getgarnetteamscore());
                            zone1.setgoldscore(currentZone.getgoldteamscore());
                            Log.i("MainActivity", "Zone1:  " + String.valueOf(zone1.garnetteamscore) + " "
                                    + String.valueOf(zone1.goldteamscore));
                            break;
                        }
                        case ("Zone2"): {
                            zone2.setgarnetscore(currentZone.getgarnetteamscore());
                            zone2.setgoldscore(currentZone.getgoldteamscore());
                            Log.i("MainActivity", "Zone2:  " + String.valueOf(zone2.garnetteamscore) + " "
                                    + String.valueOf(zone2.goldteamscore));
                            break;
                        }
                        case ("Zone3"): {
                            zone3.setgarnetscore(currentZone.getgarnetteamscore());
                            zone3.setgoldscore(currentZone.getgoldteamscore());
                            Log.i("MainActivity", "Zone3:  " + String.valueOf(zone3.garnetteamscore) + " "
                                    + String.valueOf(zone3.goldteamscore));
                            break;
                        }
                        case ("Zone4"): {
                            zone4.setgarnetscore(currentZone.getgarnetteamscore());
                            zone4.setgoldscore(currentZone.getgoldteamscore());
                            Log.i("MainActivity", "Zone4:  " + String.valueOf(zone4.garnetteamscore) + " "
                                    + String.valueOf(zone4.goldteamscore));
                            break;
                        }
                        case ("Zone5"): {
                            zone5.setgarnetscore(currentZone.getgarnetteamscore());
                            zone5.setgoldscore(currentZone.getgoldteamscore());
                            Log.i("MainActivity", "Zone5:  " + String.valueOf(zone5.garnetteamscore) + " "
                                    + String.valueOf(zone5.goldteamscore));
                            break;
                        }
                        case ("Zone6"): {
                            zone6.setgarnetscore(currentZone.getgarnetteamscore());
                            zone6.setgoldscore(currentZone.getgoldteamscore());
                            Log.i("MainActivity", "Zone6:  " + String.valueOf(zone6.garnetteamscore) + " "
                                    + String.valueOf(zone6.goldteamscore));
                            break;
                        }
                        default:
                            break;
                    }

                    //m.put(zoneSnapshot.getKey(), currentZone);
                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.i("Main Activity", "Database read cancelled");
            }
        });

        GoogleSignInOptions gso = new
                GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(MainActivity.this, new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                        Toast.makeText(MainActivity.this, "CONNECTION FAILED", Toast.LENGTH_SHORT).show();
                    }
                } /* OnConnectionFailedListener*/)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();


        FragmentManager fManager = getSupportFragmentManager();
        FragmentTransaction fTransaction = fManager.beginTransaction();
        //Check if anyone is already logged in
        if (auth.getCurrentUser() != null) {
            fTransaction.add(R.id.main_frame,
                    GameFragment.newInstance(new MyUser(auth.getCurrentUser().getEmail(), "PLACEHOLDER ID")));
        } else
        fTransaction.add(R.id.main_frame, MainFragment.newInstance());

        fTransaction.commit();

    }

    private void login() {
        Toast.makeText(this, auth.getCurrentUser().getEmail(), Toast.LENGTH_SHORT).show();
    }

    //TODO - GET RID OF THIS TEST METHOD
    private void pushToDatabase(FirebaseUser user, String data) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();

        MyUser userObject = new MyUser(user.getEmail(), data);
        Map<String, Object> m = new HashMap<String, Object>();
        m.put("Gman", userObject);
        reference.updateChildren(m);
    }

    private void getZoneInfo(String zoneKey) {

        switch (zoneKey) {
            case "Zone1": {
                Log.i("MainActivity", zone1.getgarnetteamscore() + " " +
                        zone1.getgoldteamscore());
                break;
            }
            case "Zone2": {
                Log.i("MainActivity", zone2.getgarnetteamscore() + " " +
                        zone2.getgoldteamscore());
                break;
            }
            case "Zone3": {
                Log.i("MainActivity", zone3.getgarnetteamscore() + " " +
                        zone3.getgoldteamscore());
                break;
            }
            case "Zone4": {
                Log.i("MainActivity", zone4.getgarnetteamscore() + " " +
                        zone4.getgoldteamscore());
                break;
            }
            case "Zone5": {
                Log.i("MainActivity", zone5.getgarnetteamscore() + " " +
                        zone5.getgoldteamscore());
                break;
            }
            case "Zone6": {
                Log.i("MainActivity", zone6.getgarnetteamscore() + " " +
                        zone6.getgoldteamscore());
                break;
            }
            default: {
                Toast.makeText(this, "Invalid Key", Toast.LENGTH_SHORT).show();
                return;
            }


        }

    }

    private void incrementGarnetScore(String zoneKey) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        Zone newZone = new Zone();

        switch (zoneKey) {
            case "Zone1": {
                newZone.setgarnetscore(zone1.getgarnetteamscore() + 20);
                newZone.setgoldscore(zone1.getgoldteamscore());
                break;
            }
            case "Zone2": {
                newZone.setgarnetscore(zone2.getgarnetteamscore() + 20);
                newZone.setgoldscore(zone2.getgoldteamscore());
                break;
            }
            case "Zone3": {
                newZone.setgarnetscore(zone3.getgarnetteamscore() + 20);
                newZone.setgoldscore(zone3.getgoldteamscore());
                break;
            }
            case "Zone4": {
                newZone.setgarnetscore(zone4.getgarnetteamscore() + 20);
                newZone.setgoldscore(zone4.getgoldteamscore());
                break;
            }
            case "Zone5": {
                newZone.setgarnetscore(zone5.getgarnetteamscore() + 20);
                newZone.setgoldscore(zone5.getgoldteamscore());
                break;
            }
            case "Zone6": {
                newZone.setgarnetscore(zone6.getgarnetteamscore() + 20);
                newZone.setgoldscore(zone6.getgoldteamscore());
                break;
            }
            default: {
                Toast.makeText(this, "Invalid Key", Toast.LENGTH_SHORT).show();
                return;
            }

        }

        Map<String, Object> m = new HashMap<String, Object>();
        m.put(zoneKey, newZone);
        reference.updateChildren(m);


    }

    private void incrementGoldScore(String zoneKey) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        Zone newZone = new Zone();

        switch (zoneKey) {
            case "Zone1": {
                newZone.setgarnetscore(zone1.getgarnetteamscore());
                newZone.setgoldscore(zone1.getgoldteamscore() + 20);
                break;
            }
            case "Zone2": {
                newZone.setgarnetscore(zone2.getgarnetteamscore());
                newZone.setgoldscore(zone2.getgoldteamscore() + 20);
                break;
            }
            case "Zone3": {
                newZone.setgarnetscore(zone3.getgarnetteamscore());
                newZone.setgoldscore(zone3.getgoldteamscore() + 20);
                break;
            }
            case "Zone4": {
                newZone.setgarnetscore(zone4.getgarnetteamscore());
                newZone.setgoldscore(zone4.getgoldteamscore() + 20);
                break;
            }
            case "Zone5": {
                newZone.setgarnetscore(zone5.getgarnetteamscore());
                newZone.setgoldscore(zone5.getgoldteamscore() + 20);
                break;
            }
            case "Zone6": {
                newZone.setgarnetscore(zone6.getgarnetteamscore());
                newZone.setgoldscore(zone6.getgoldteamscore() + 20);
                break;
            }
            default: {
                Toast.makeText(this, "Invalid Key", Toast.LENGTH_SHORT).show();
                return;
            }

        }

        Map<String, Object> m = new HashMap<String, Object>();
        m.put(zoneKey, newZone);
        reference.updateChildren(m);
    }

}

