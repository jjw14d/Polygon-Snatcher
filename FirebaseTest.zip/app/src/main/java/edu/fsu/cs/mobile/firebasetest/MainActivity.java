package edu.fsu.cs.mobile.firebasetest;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth auth;
    EditText emailField;
    EditText passwordField;
    Button loginButton;
    Button registerButton;
    GoogleApiClient mGoogleApiClient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null)
            Toast.makeText(this, "PRELOGGED USER:" + auth.getCurrentUser().getEmail(), Toast.LENGTH_SHORT).show();


        emailField = (EditText) findViewById(R.id.email_field);
        passwordField = (EditText) findViewById(R.id.password_field);

        loginButton = (Button) findViewById(R.id.login_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        registerButton = (Button) findViewById(R.id.register_button);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });

        GoogleSignInOptions gso = new
                GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleApiClient= new GoogleApiClient.Builder(this)
                .enableAutoManage(MainActivity.this, new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                        Toast.makeText(MainActivity.this, "CONNECTION FAILED", Toast.LENGTH_SHORT).show();
                    }
                } /* OnConnectionFailedListener */)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();



    }

    private void register(){
        String email = emailField.getText().toString();
        String password = passwordField.getText().toString();


        auth.createUserWithEmailAndPassword(email, password);

    }

    private void login() {



        String email = emailField.getText().toString();
        String password = passwordField.getText().toString();


        auth.signInWithEmailAndPassword(email, password);


        if (auth.getCurrentUser() == null)
            Toast.makeText(this, "USER NOT SIGNED IN", Toast.LENGTH_SHORT).show();
        else {
            Toast.makeText(this, auth.getCurrentUser().getEmail(), Toast.LENGTH_SHORT).show();
        }

        if (!auth.getCurrentUser().getEmail().equals(email))
            Toast.makeText(this, "UHOH", Toast.LENGTH_SHORT).show();

        auth.signOut();
    }
}

