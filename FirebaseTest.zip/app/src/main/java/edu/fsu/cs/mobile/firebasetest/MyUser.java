package edu.fsu.cs.mobile.firebasetest;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Remmy on 7/12/17.
 */

public class MyUser {
    private String email;
    private String password;

    MyUser(){
        email = "";
        password = "";
    }

    MyUser(String mail, String pass){
        email = mail;
        password = pass;
    }

    public String getPassword(){
        return password;
    }

    public String getEmail(){
        return email;
    }

    public Map<String, Object> toMap(){
        Map<String,Object> m = new HashMap<String, Object>();

        m.put(email, this);

        return m;

    }


}
